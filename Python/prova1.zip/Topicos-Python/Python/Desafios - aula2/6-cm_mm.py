n = int(input("Digite um valor em metros: "))

print(f"\n{n}m correspondem a {n*100}cm e {n*1000}mm.")

input("\nDigite enter para sair")