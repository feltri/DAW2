import math

n = float(input("Digite um número: "))

print(f"\nSeu dobro é = {n*2}")
print(f"Seu triplo é = {n*3}")
print(f"Sua raiz quadrada é = {math.sqrt(n)}")

input("\nDigite enter para sair")