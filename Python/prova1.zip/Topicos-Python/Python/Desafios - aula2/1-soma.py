n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

print(f"A soma dos valores é = {n1+n2}")

input("Digite enter para sair")