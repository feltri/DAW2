n1 = float(input("Digite sua primeira nota: "))
n2 = float(input("Digite sua segunda nota: "))

print(f"\nSua média é = {(n1+n2)/2}")

input("\nDigite enter para sair")