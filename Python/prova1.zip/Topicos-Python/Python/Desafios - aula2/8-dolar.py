valor = float(input("Digite o valor em dinheiro: "))
dolar = float(5)

print(f"\nA conversão do valor para dólar é = $ {valor/dolar}.")

input("\nDigite enter para sair")