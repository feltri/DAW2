n = int(input("Digite um valor para exibir sua tabuada: "))

print("\n")
for i in range(0, 11, +1):
    print(f"{n} x {i} = {n*i}")

input("\nDigite enter para sair")
