nome = (input("Digite seu nome compelto: "))

maiuscula = nome.upper()
print(maiuscula)

minuscula = nome.lower()
print(minuscula)

qnt_letras = len(nome)
print(qnt_letras)

primeira = nome.split()[0]
print(len(primeira))