n = (input("Digite um número entre 0 e 9999: "))

u = n[3]
print(f"Unidade = {u}")

d = n[2]
print(f"Dezena = {d}")

c = n[1]
print(f"Centena = {c}")

m = n[0]
print(f"Milhar = {m}")