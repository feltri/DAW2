frase = (input("Digite uma frase: "))

frase.lower()

print(f"Aparece a letra 'a' {frase.count("a")} vezes")
