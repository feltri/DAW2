nome = (input("Digite seu nome completo: "))

nome.lower()

c = "silva" in nome

if(c == 'true'):
    print("Seu nome contém 'Silva'!")
else:
    print("Seu nome não contém 'Silva'!")