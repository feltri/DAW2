from validacoes import validaNome, validaCpf, validaTel


print("------------------------------ ANÁLISE DE CRÉDITO ------------------------------")
print("\nPreencha o formulário para solicitação da análise:\n")

nome = input("Nome completo: ")
cpf = input("CPF: ")
tel = input("Telefone/celular: ")
email = input("E-mail: ")
cep = input("CEP: ")
endereco = input("Endereço: ")
sal = float(input("Salário líquido: "))
val = float(input("Valor do empréstimo: "))
meses = int(input("Quantidade de parcelas: "))

print("\n\n")

if validaNome(nome) == False:
    print("Insira seu nome completo")

if validaCpf(cpf) == False:
    print("CPF Inválido")

if validaTel(tel) == False:
    print("Telefone Inválido")