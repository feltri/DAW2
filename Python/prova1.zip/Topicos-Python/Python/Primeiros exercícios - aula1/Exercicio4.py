b = float(input("Digite a base do retângulo: "))

h = float(input("Digite a altura do retângulo: "))

print(f"Área = {b*h}")
print(f"Perímetro = {2*b + h*2}")

input("Digite enter para sair")