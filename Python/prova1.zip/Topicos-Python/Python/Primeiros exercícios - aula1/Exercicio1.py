n = float(input("Digite um número inteiro: "))

print(f"O número digitado ao quadrado  = {n*n}")

input("Digite enter para sair")