c1 = str(input("Digite o caracter 1: "))

c2 = str(input("Digite o caracter 2: "))

print(f"O usuário digitou: {c1} e {c2}")

input("Digite enter para sair")