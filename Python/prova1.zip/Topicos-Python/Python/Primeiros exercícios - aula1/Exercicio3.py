n = int(input("Digite um número inteiro: "))

print(f"O antecessor do número é {n-1} e o sucessor é {n+1}")

input("Digite enter para sair")