n1 = int(input("Digite um número inteiro: "))
n2 = int(input("Digite outro número inteiro: "))

if n1 == n2:
    print("Os números são iguais!")
else:
    print("Os números são diferentes!")