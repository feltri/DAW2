n1 = int(input("Digite um número: "))
n2 = int(input("Digite outro número: "))
n3 = int(input("Digite outro número: "))

m = max(n1,n2,n3)

print(f"O maior número é {m}")