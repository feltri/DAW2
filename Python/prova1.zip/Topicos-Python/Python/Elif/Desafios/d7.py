sal = float(input("Digite seu salário: "))

if sal > 1250:
    sal_novo = sal + sal * 0.10
else:
    sal_novo = sal + sal * 0.15

print(f"Novo salário = R$ {sal_novo}")