<?php
$a = array("201345", "Marco Antonio Felicio",
           "208374", "Maria Clara Minosi",
           "203498", "Justino Jesus");

foreach($a as $array){
    echo $array . "<br>";
}