<?php
echo "Data: " . date('d-m-Y', 164926800);