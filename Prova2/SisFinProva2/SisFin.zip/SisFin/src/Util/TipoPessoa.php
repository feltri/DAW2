<?php
namespace Sisfin\Util;

enum TipoPessoa : int
{
    case PESSOA_FISICA = 1;
    case PESSOA_JURIDICA = 2;
}